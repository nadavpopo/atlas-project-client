import React,{Component} from "react";
import ChildColor from "./childColor";

class AppColor extends Component{
  // סטייט מייצג את כל המשתנים הדינמים
  // של הקומפנינטה עצמה ,
  // שגם היא יכול להוריש לקומפ ילדים
  // שלה
  state = {fontColor:"pink"}

  changeFontColor = (_color) => {
    // כדי לשנות  מאפיין בסטייט חייבים לעשות את זה דרך הפוקנציה הבאה
    this.setState({fontColor:_color})
  }

  render(){
    return(
      <div className="container text-center">
        <div>
          <h2 style={{color:this.state.fontColor}}>
            {/* פרופס משמש לקבל מאפיינים שהועברו מקומפ
            האבא */}
            {this.props.h2Text}
            </h2>
            <ChildColor changeFontColor={this.changeFontColor} />
        </div>
        AppColor work
      </div>
    
    )
  }
}

export default AppColor;