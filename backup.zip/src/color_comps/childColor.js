import React, { Component } from "react";

class ChildColor extends Component {
  render() {
    return (
      <div className="mt-4">
        <button onClick={() => { this.props.changeFontColor("red") }}>Red</button>
        <button onClick={() => { this.props.changeFontColor("blue") }}>Blue</button>
        <button onClick={() => { this.props.changeFontColor("orange") }}>Orange</button>
      </div>

    )
  }
}

export default ChildColor;