import React from 'react';
import './App.css';
import AppColor from './color_comps/appColor';
import AppExchange from './exchange_comps/appExchange';
import AppVip from './vip_comps/appVip';
import AppCartoon from './cartoon_comps/appCartoon';
import Pixa from './pixa_comps/appPixa';

function App() {
  return (
    <div className="App">
      <Pixa/>
      <hr />
      <AppCartoon />
      <hr />
      {/* <AppVip />
      <hr/>
      <AppExchange />
      <hr /> */}
    </div>
  );
}

export default App;
