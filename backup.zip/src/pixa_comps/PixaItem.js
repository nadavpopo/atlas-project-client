import React, { Component } from 'react';

class PixaItem extends Component
{
  render()
  {
        let item = this.props.item; 

    return (
        <div className="col-lg-6 border">
            <img src = {item.previewURL} className="float-left mr-2 w-25" />
            <h3>User: {item.user}</h3>
            <div>Tags: {item.tags}</div>
        </div>
    )
  }
}

export default PixaItem


