import React,{Component} from "react";
import { unmountComponentAtNode } from "react-dom";


class Search extends Component{
    render()
    {
        return(
            <div className="col-lg-6 row">
                <h1>Pixa search api</h1>
                <input className="form-control col-lg-8 mr-4"/>
                <button className="btn btn-info">Search pix</button>
            </div>
        )
    }
}

export default Search;