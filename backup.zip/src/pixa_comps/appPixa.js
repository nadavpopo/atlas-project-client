import React,{Component} from "react";
import Search from "./serch";
import Main from "./main";
import { doApi } from "../service/apiSerGet";

class Pixa extends Component
{
    state = {_ar:[]}

    componentDidMount()
    {
        let myUrl = "http://fs1.co.il/bus/pixa1.php";
        doApi(myUrl)
        .then(data =>
            {
                console.log(data);
                this.setState({_ar:data});
            })
    }


  render(){
    return(
        <div className="container">
            <Search func={this.componentDidMount}/>
            <Main ar={this.state._ar}/>
        </div>
    )
  }
}

export default Pixa;