import React,{Component} from "react";
import PixaItem from "./PixaItem";

class Main extends Component
{  
    render()
    {
        return(
            <div className="mt-4 row">
                {this.props.ar.map(item =>
                    {
                        return(
                            <PixaItem item={item} key={item.id}/>
                        )
                    }
                )}
            </div>
        )
    }
}

export default Main;