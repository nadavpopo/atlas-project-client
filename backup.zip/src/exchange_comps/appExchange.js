import React,{Component} from "react";
import Inputs from "./inputs";
import Total from "./total";

class AppExchange extends Component{
  state = {amount:100,coin:"3.45"}

  changeCoinAndAmount = (_amount,_coin) => {
    this.setState({amount:_amount,coin:_coin});
  }


  render(){
    return(
      <div className="container">
       <h2>App exchange</h2>
       <Inputs changeCoinAndAmount={this.changeCoinAndAmount}/>
       <Total amount={this.state.amount} coin={this.state.coin} />
      </div>
    
    )
  }
}

export default AppExchange;