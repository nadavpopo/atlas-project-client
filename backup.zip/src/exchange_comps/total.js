import React, { Component } from "react";

class Total extends Component {
  state = { total: 0 }

  // פונקציה שפועלת בפעם הראשונה שהקומפנינטה מוצגת בדומה
  // לINIT של גיי אס רגיל
  componentDidMount() {
    this.setState({ total: this.props.amount * this.props.coin });
  }

  // הפונקציה פועל גם שמעדכנים סטייט וגם פרופס
  componentDidUpdate(_prevProps, _prevState) {
    if (this.props !== _prevProps) {
      this.setState({ total: this.props.amount * this.props.coin })
    }
  }


  render() {
    return (
      <div className="col-lg-6">
        <h3>You will get: {this.state.total} NIS</h3>
      </div>

    )
  }
}

export default Total;