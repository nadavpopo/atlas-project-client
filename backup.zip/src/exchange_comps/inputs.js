import React,{Component} from "react";

class Inputs extends Component{
  // כדי לדבר עם מידע באינפוט או סלקט
  selectCoin = React.createRef();
  inputAmount = React.createRef()

  coinOrAmountChange = () => {
    console.log(this.inputAmount)
    this.props.changeCoinAndAmount(this.inputAmount.current.value,
      this.selectCoin.current.value)
  }

  render(){
    return(
      <div className="col-lg-6">
        <label>Choose coin:</label>
        <select onChange={this.coinOrAmountChange} ref={this.selectCoin} className="form-control"> 
          <option value="3.42">USD</option>
          <option value="3.87">EURO</option>
        </select>
        <label>Enter amount:</label>
        <input onInput={this.coinOrAmountChange} ref={this.inputAmount} className="form-control" type="number" defaultValue="100"/>
      </div>
    
    )
  }
}

export default Inputs;